<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.master','data' => ['title' => 'Application Forms','menutitle' => 'ethical']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Application Forms','menutitle' => 'ethical']); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.breadcrumb','data' => ['title' => 'Application Forms']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Application Forms']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <!-- Application Forms Start -->
    <div class="container-fluid py-1">
        <div class="container py-1">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <h6 class="mb-4">A brief description and links to download CHREC ethical approval forms. Please download and fill any of the forms below as may apply to your research.</h6>
                    <div class="contact-form bg-secondary rounded p-5">
                        <div id="success"></div>
                        <div class="container">
                            <h4>Application forms</h4>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Form Type</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Form 005: Student Investigator</td>
                                        <td>For students in any categories e.g BSc, MSc, and PhD</td>
                                        <td><u><a href="<?php echo e(asset('@assets/forms/STUDENT INVESTIGATOR.pdf')); ?>" download>Download</a></u></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Form 009: Animal form</td>
                                        <td>For research involving animals</td>
                                        <td><u><a href="<?php echo e(asset('@assets/forms/ANIMAL FORM.pdf')); ?>" download>Download</a></u></td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>Form 002: Non-Student investigators</td>
                                        <td>For non-students</td>
                                        <td><u><a href="<?php echo e(asset('@assets/forms/NON STUDENT FORM.pdf')); ?>" download>Download</a></u></td>
                                    </tr>
                                    <tr>
                                        <td>4</td>
                                        <td>Consent form</td>
                                        <td>Inform Consent Form <i>(If applicable)</i></td>
                                        <td><u><a href="<?php echo e(asset('@assets/forms/INFORM CONSENT FORM NHREC.pdf')); ?>" download>Download</a></u></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <p class="mt-4">Kindly ensure you have gone through the <u><a href="<?php echo e(route('application-checklist')); ?>">CHREC application checklist</a></u> for ethical approval at Covenant University before filling and submitting the form.</p>
                </div>
            </div>
        </div>
    </div>
<!-- Application Forms End -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\Jerry\Desktop\Projects\chrec\resources\views/application-forms.blade.php ENDPATH**/ ?>