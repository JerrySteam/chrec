<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('@assets/lib/easing/easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('@assets/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>

<!-- Contact Javascript File -->
<script src="<?php echo e(asset('@assets/mail/jqBootstrapValidation.min.js')); ?>"></script>


<!-- Template Javascript -->
<script src="<?php echo e(asset('@assets/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('@assets/js/custom.js')); ?>"></script><?php /**PATH C:\Users\Jerry\Desktop\Projects\chrec\resources\views/components/layouts/scripts.blade.php ENDPATH**/ ?>