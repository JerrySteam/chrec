<x-layouts.master title="About">
  <x-layouts.breadcrumb title="About"/>
</x-layouts.master>